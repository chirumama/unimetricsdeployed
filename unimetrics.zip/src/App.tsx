/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Layout from './components/Layout';
import AdminDashboard from './pages/admin/AdminDashboard';
import AcademicYear from './pages/admin/AcademicYear';
import FacultyManagement from './pages/admin/FacultyManagement';
import FacultyDashboard from './pages/faculty/FacultyDashboard';
import StudentManagement from './pages/faculty/StudentManagement';
import FacultyAttendance from './pages/faculty/FacultyAttendance';
import StudentDashboard from './pages/student/StudentDashboard';
import StudentAttendance from './pages/student/StudentAttendance';
import PlaceholderPage from './pages/PlaceholderPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        
        {/* Admin Routes */}
        <Route path="/admin" element={<Layout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="academic-year" element={<AcademicYear />} />
          <Route path="faculty-management" element={<FacultyManagement />} />
          <Route path="timetable" element={<PlaceholderPage />} />
          <Route path="faculty-attendance" element={<PlaceholderPage />} />
          <Route path="finance" element={<PlaceholderPage />} />
          <Route path="notices" element={<PlaceholderPage />} />
          <Route path="logs" element={<PlaceholderPage />} />
        </Route>

        {/* Faculty Routes */}
        <Route path="/faculty" element={<Layout />}>
          <Route index element={<FacultyDashboard />} />
          <Route path="students" element={<StudentManagement />} />
          <Route path="attendance" element={<FacultyAttendance />} />
          <Route path="marks" element={<PlaceholderPage />} />
          <Route path="materials" element={<PlaceholderPage />} />
          <Route path="doubts" element={<PlaceholderPage />} />
          <Route path="timetable" element={<PlaceholderPage />} />
        </Route>

        {/* Student Routes */}
        <Route path="/student" element={<Layout />}>
          <Route index element={<StudentDashboard />} />
          <Route path="subjects" element={<PlaceholderPage />} />
          <Route path="attendance" element={<StudentAttendance />} />
          <Route path="results" element={<PlaceholderPage />} />
          <Route path="notifications" element={<PlaceholderPage />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
