import React, { useState } from 'react';
import { 
  CheckSquare, 
  Calendar,
  Clock,
  AlertCircle
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function StudentAttendance() {
  const [isPunchInActive, setIsPunchInActive] = useState(true); // Mocking active state
  const [hasPunchedIn, setHasPunchedIn] = useState(false);

  const handlePunchIn = () => {
    setHasPunchedIn(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">My Attendance</h1>
          <p className="text-gray-500">View your attendance records and punch in for active classes.</p>
        </div>
      </div>

      <Card className={`border-2 ${isPunchInActive && !hasPunchedIn ? 'border-indigo-500 shadow-md' : ''}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-indigo-600" />
                Live Class Punch-in
              </CardTitle>
              <CardDescription>
                {isPunchInActive 
                  ? "Your faculty has activated punch-in mode. Mark your attendance now." 
                  : "No active punch-in sessions at the moment."}
              </CardDescription>
            </div>
            {isPunchInActive && !hasPunchedIn && (
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-indigo-500"></span>
              </span>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {isPunchInActive ? (
            <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-indigo-50 rounded-lg border border-indigo-100">
              <div className="mb-4 sm:mb-0">
                <h3 className="font-semibold text-indigo-900">Data Structures</h3>
                <p className="text-sm text-indigo-700">Prof. Sarah Smith • Room 302</p>
              </div>
              <Button 
                size="lg" 
                onClick={handlePunchIn}
                disabled={hasPunchedIn}
                className={hasPunchedIn ? "bg-green-600 hover:bg-green-700" : ""}
              >
                {hasPunchedIn ? (
                  <>
                    <CheckSquare className="mr-2 h-5 w-5" />
                    Attendance Marked
                  </>
                ) : (
                  "Punch In Now"
                )}
              </Button>
            </div>
          ) : (
            <div className="flex items-center justify-center p-6 text-gray-500 bg-gray-50 rounded-lg border border-dashed">
              <AlertCircle className="mr-2 h-5 w-5" />
              Waiting for faculty to activate punch-in mode...
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Attendance</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <p className="text-xs text-muted-foreground text-green-600 mt-1">
              Above required 75%
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Classes Attended</CardTitle>
            <CheckSquare className="h-4 w-4 text-muted-foreground text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">142</div>
            <p className="text-xs text-muted-foreground text-gray-500 mt-1">
              Out of 168 total classes
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Leaves Taken</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
            <p className="text-xs text-muted-foreground text-gray-500 mt-1">
              2 medical, 2 casual
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
