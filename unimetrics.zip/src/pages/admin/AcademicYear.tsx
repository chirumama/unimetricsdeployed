import React, { useState } from 'react';
import { 
  CalendarDays, 
  Play, 
  Square, 
  Plus, 
  Users, 
  BookOpen 
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function AcademicYear() {
  const [isCycleActive, setIsCycleActive] = useState(false);
  const [currentYear, setCurrentYear] = useState('2025-2026');

  const handleToggleCycle = () => {
    if (isCycleActive) {
      if (window.confirm('Are you sure you want to stop the current academic cycle? All data will be archived.')) {
        setIsCycleActive(false);
      }
    } else {
      setIsCycleActive(true);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">Academic Year Management</h1>
          <p className="text-gray-500">Manage academic cycles, classes, and divisions.</p>
        </div>
        <Button 
          variant={isCycleActive ? "destructive" : "default"}
          onClick={handleToggleCycle}
          className="flex items-center gap-2"
        >
          {isCycleActive ? (
            <>
              <Square className="h-4 w-4" />
              Stop Academic Cycle
            </>
          ) : (
            <>
              <Play className="h-4 w-4" />
              Start New Cycle
            </>
          )}
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Current Cycle Status</CardTitle>
            <CardDescription>Status of the academic year</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg bg-gray-50">
              <div className="flex items-center gap-3">
                <CalendarDays className="h-5 w-5 text-indigo-600" />
                <div>
                  <p className="font-medium text-gray-900">Academic Year</p>
                  <p className="text-sm text-gray-500">{currentYear}</p>
                </div>
              </div>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                isCycleActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
              }`}>
                {isCycleActive ? 'Active' : 'Stopped'}
              </span>
            </div>

            {!isCycleActive && (
              <div className="space-y-2 pt-4 border-t">
                <label className="text-sm font-medium text-gray-700">Set New Academic Year</label>
                <div className="flex gap-2">
                  <Input 
                    value={currentYear} 
                    onChange={(e) => setCurrentYear(e.target.value)}
                    placeholder="e.g. 2026-2027"
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Classes & Divisions</CardTitle>
              <CardDescription>Manage classes for the current cycle</CardDescription>
            </div>
            <Button size="sm" disabled={!isCycleActive} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Class
            </Button>
          </CardHeader>
          <CardContent>
            {isCycleActive ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class Name</TableHead>
                    <TableHead>Divisions</TableHead>
                    <TableHead>Total Students</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">First Year (FY)</TableCell>
                    <TableCell>A, B, C</TableCell>
                    <TableCell>180</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">Manage</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Second Year (SY)</TableCell>
                    <TableCell>A, B</TableCell>
                    <TableCell>120</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">Manage</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Third Year (TY)</TableCell>
                    <TableCell>A, B</TableCell>
                    <TableCell>115</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm">Manage</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            ) : (
              <div className="h-48 flex flex-col items-center justify-center text-center border-2 border-dashed rounded-lg p-6">
                <CalendarDays className="h-10 w-10 text-gray-400 mb-2" />
                <h3 className="text-lg font-medium text-gray-900">Cycle is Stopped</h3>
                <p className="text-sm text-gray-500 max-w-sm mt-1">
                  Start a new academic cycle to manage classes and divisions.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
