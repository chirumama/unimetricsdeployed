import React from 'react';
import { 
  Users, 
  Plus, 
  Search,
  MoreVertical
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const mockFaculty = [
  { id: 'F001', name: 'Dr. Sarah Smith', username: 'sarah.s', dob: '1980-05-15', subjects: ['Data Structures', 'Algorithms'], classes: ['FY-A', 'SY-B'] },
  { id: 'F002', name: 'Prof. John Doe', username: 'john.d', dob: '1975-11-22', subjects: ['Database Systems'], classes: ['TY-A'] },
  { id: 'F003', name: 'Dr. Emily Chen', username: 'emily.c', dob: '1988-03-10', subjects: ['Software Engineering', 'Web Dev'], classes: ['SY-A', 'TY-B'] },
];

export default function FacultyManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">Faculty Management</h1>
          <p className="text-gray-500">Add faculty, assign subjects, and manage access.</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Add New Faculty
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Faculty Directory</CardTitle>
              <CardDescription>List of all registered faculty members</CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
              <Input placeholder="Search faculty..." className="pl-8" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Profile</TableHead>
                <TableHead>Name & Username</TableHead>
                <TableHead>Assigned Subjects</TableHead>
                <TableHead>Assigned Classes</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockFaculty.map((faculty) => (
                <TableRow key={faculty.id}>
                  <TableCell>
                    <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
                      {faculty.name.charAt(0)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium text-gray-900">{faculty.name}</p>
                      <p className="text-sm text-gray-500">@{faculty.username}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {faculty.subjects.map(sub => (
                        <span key={sub} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          {sub}
                        </span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {faculty.classes.map(cls => (
                        <span key={cls} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                          {cls}
                        </span>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">Edit</Button>
                    <Button variant="ghost" size="sm" className="text-indigo-600">Assign</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
