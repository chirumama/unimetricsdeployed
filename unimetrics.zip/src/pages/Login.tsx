import React from 'react';
import { useNavigate } from 'react-router-dom';
import { GraduationCap, User, Shield, BookOpen } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function Login() {
  const navigate = useNavigate();

  const handleLogin = (role: 'admin' | 'faculty' | 'student') => {
    // In a real app, this would set auth state and redirect
    navigate(`/${role}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="flex justify-center">
          <div className="h-16 w-16 bg-indigo-600 rounded-full flex items-center justify-center">
            <GraduationCap className="h-10 w-10 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          UniMetrics Dashboard
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          University and College Metrics Management System
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <Card>
          <CardHeader>
            <CardTitle className="text-center">Select Role to Continue</CardTitle>
            <CardDescription className="text-center">
              Choose your account type to access the dashboard
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              variant="outline" 
              className="w-full h-16 text-lg justify-start px-6 hover:border-indigo-600 hover:text-indigo-600 hover:bg-indigo-50"
              onClick={() => handleLogin('admin')}
            >
              <Shield className="mr-4 h-6 w-6" />
              Administrator
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full h-16 text-lg justify-start px-6 hover:border-indigo-600 hover:text-indigo-600 hover:bg-indigo-50"
              onClick={() => handleLogin('faculty')}
            >
              <BookOpen className="mr-4 h-6 w-6" />
              Faculty Member
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full h-16 text-lg justify-start px-6 hover:border-indigo-600 hover:text-indigo-600 hover:bg-indigo-50"
              onClick={() => handleLogin('student')}
            >
              <User className="mr-4 h-6 w-6" />
              Student
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
