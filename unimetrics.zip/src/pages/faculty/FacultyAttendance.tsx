import React, { useState } from 'react';
import { 
  CheckSquare, 
  Calendar,
  Clock,
  Save
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const mockStudents = [
  { id: 'S001', name: 'Alice Johnson', rollNo: '101', status: 'present' },
  { id: 'S002', name: 'Bob Smith', rollNo: '102', status: 'absent' },
  { id: 'S003', name: 'Charlie Davis', rollNo: '103', status: 'present' },
  { id: 'S004', name: 'Diana Prince', rollNo: '104', status: 'present' },
  { id: 'S005', name: 'Evan Wright', rollNo: '105', status: 'late' },
];

export default function FacultyAttendance() {
  const [isPunchInActive, setIsPunchInActive] = useState(false);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">Mark Attendance</h1>
          <p className="text-gray-500">Record student attendance for your current class.</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant={isPunchInActive ? "destructive" : "outline"}
            onClick={() => setIsPunchInActive(!isPunchInActive)}
            className="flex items-center gap-2"
          >
            <Clock className="h-4 w-4" />
            {isPunchInActive ? 'Stop Punch-in Mode' : 'Activate Punch-in Mode'}
          </Button>
          <Button className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Attendance
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Class</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Data Structures</div>
            <p className="text-xs text-muted-foreground text-gray-500 mt-1">
              FY-A • 10:00 AM - 11:00 AM
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Present</CardTitle>
            <CheckSquare className="h-4 w-4 text-muted-foreground text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">42/45</div>
            <p className="text-xs text-muted-foreground text-gray-500 mt-1">
              93% Attendance Rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Punch-in Status</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${isPunchInActive ? 'text-blue-600' : 'text-gray-500'}`}>
              {isPunchInActive ? 'Active' : 'Inactive'}
            </div>
            <p className="text-xs text-muted-foreground text-gray-500 mt-1">
              {isPunchInActive ? 'Students can mark attendance via app' : 'Manual marking only'}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Student List</CardTitle>
          <CardDescription>Verify and mark attendance manually</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Roll No</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.rollNo}</TableCell>
                  <TableCell>{student.name}</TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      student.status === 'present' ? 'bg-green-100 text-green-800' : 
                      student.status === 'absent' ? 'bg-red-100 text-red-800' : 
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {student.status.charAt(0).toUpperCase() + student.status.slice(1)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button variant="outline" size="sm" className="text-green-600 border-green-200 hover:bg-green-50">P</Button>
                    <Button variant="outline" size="sm" className="text-red-600 border-red-200 hover:bg-red-50">A</Button>
                    <Button variant="outline" size="sm" className="text-yellow-600 border-yellow-200 hover:bg-yellow-50">L</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
